<?php 
    session_start();

    $conn=mysqli_connect( "172.16.1.11","my_user","my_password","my_db")or die(mysqli_error($mysqli));
?>